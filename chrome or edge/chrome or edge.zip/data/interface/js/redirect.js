$(document).ready(function(){
  var localize = new Localize();
  localize.init();
});